let output = "#";

while(output.length < 8){
    console.log(output);
    output += "#";
}